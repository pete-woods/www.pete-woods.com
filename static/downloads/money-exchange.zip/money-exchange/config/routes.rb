Rails.application.routes.draw do
  get 'exchange/index'
  get 'exchange', to: 'exchange#index'
  root 'exchange#index'
end
