Rails.application.config.after_initialize do
  require 'exchange_rate'
  ExchangeRate.update
end