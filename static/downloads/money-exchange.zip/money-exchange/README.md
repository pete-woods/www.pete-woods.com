# README

A very simple web server to convert between currencies listed on the ECB exchange rate site.

Built against Rails 5.1.1 with Ruby 2.4. Using the following additional Gems:

* nokogiri >= 1.6.0
* money >= 6.0.0
* monetize >= 1.6.0

## ExchangeRate API

The exchange rate between two currencies for a specific day can be retrieved as follows:

```
ExchangeRate.at(Date.today,'GBP','USD')
```

To convert between two different currencies:

```
ExchangeRate.convert(Date.today, '100', 'GBP', 'USD')
```

## Caching
The server automatically caches the current data from the ECB at startup in a Rails initializer.
 
The cache can be updated at any time with the following rake task:
```
bin/rake refresh_ecb_cache
```

