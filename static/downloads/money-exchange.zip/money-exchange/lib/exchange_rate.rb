require 'net/http'

class DateUnavailable < StandardError; end

class CurrencyUnavailable < StandardError; end

module ExchangeRate
  FX_URI = URI('http://www.ecb.europa.eu/stats/eurofxref/eurofxref-hist-90d.xml')
  TMP_PATH = Rails.root.join('tmp').freeze
  CACHE_PATH = TMP_PATH.join('eurofxref-hist-90d.xml').freeze
  CURRENCIES = %w(EUR USD JPY BGN CZK DKK GBP HUF ILS PLN RON SEK CHF NOK HRK RUB TRY AUD BRL CAD CNY HKD IDR INR KRW MXN MYR NZD PHP SGD THB ZAR).map(&:freeze).freeze

  # Convert currency values between the provided currencies on the given date
  def self.convert(date, amount, from_ccy, to_ccy)
    # confine usage of money/monetize Gems to this method

    # parse the input, forcing the input currency
    money = Monetize.parse(amount, currency = from_ccy)

    # temporary bank with only the exchange rate we need
    bank = Money::Bank::VariableExchange.new(Money::RatesStore::Memory.new)
    bank.add_rate(from_ccy, to_ccy, at(date, from_ccy, to_ccy))

    # exchange the currency to the target currency and format
    bank.exchange_with(money, to_ccy).format
  end
  
  # Get a list of dates for which we have exchange rates
  def self.dates
    Rails.cache.fetch("dates", expires_in: 1.hours) do
      # xpath a list of all the days with exchange rates
      doc.xpath("//gesmes:Envelope/xmlns:Cube/xmlns:Cube/@time").map{|e| Date.parse(e.value)}
    end
  end
  
  # Get the exchange rate for the given date between the given currencies
  def self.at(date, from_ccy, to_ccy)
    # null exchange between the same currency
    return 1 if from_ccy == to_ccy
    
    # cache exchange rate
    Rails.cache.fetch("#{date}/#{from_ccy}/#{to_ccy}/rate", expires_in: 1.hours) do
      # xpath all the rates for the given date
      cubes = doc.xpath("//gesmes:Envelope/xmlns:Cube/xmlns:Cube[@time='#{date}']/xmlns:Cube")
      
      # if we can't find any data for the given date
      raise DateUnavailable if cubes.empty?
      
      # search the cubes for the to/from rates
      from_base_rate = find_rate(cubes, from_ccy)
      to_base_rate = find_rate(cubes, to_ccy)
  
      # calculate the inter-currency rate
      to_base_rate / from_base_rate
    end  
  end
  
  # Update the local cache of the ECB exchange rates
  def self.update
    # build a request for the FX URI
    req = Net::HTTP::Get.new(FX_URI)
    
    begin
      # try and get the file's last modified time
      file_info = File.stat(CACHE_PATH)
      req['If-Modified-Since'] = file_info.mtime.rfc2822
    rescue
    end
    
    res = Net::HTTP.start(FX_URI.hostname, FX_URI.port) do |http|
      http.request(req)
    end
    
    if res.is_a?(Net::HTTPSuccess)
      # only write the cache for a successful HTTP request

      # create a temp file in the railes tmpdir
      tmp = Tempfile.new('tmp.xml', tmpdir=TMP_PATH)
      begin
        # write the HTTP response body to the tempfile
        tmp.write(res.body)
        
        # rename so the cache update is atomic 
        File.rename(tmp, CACHE_PATH)
      ensure
        # good practise to clean up straight away
        tmp.close
        tmp.unlink
      end
    end
  end
  
  private
  
  # Search a list of cube XML nodes for the desired exchange rate
  def self.find_rate(cubes, ccy)
    # EUR never appears in the XML, as it is the base currency
    return 1 if ccy == "EUR"
    # try and find our desired currency
    cube = cubes.find {|cube| cube.attribute('currency').value == ccy}
    # if we couldn't find it
    raise CurrencyUnavailable unless cube
    # store the rate as an arbitrary precision value
    BigDecimal(cube.attribute('rate').value)
  end
  
  # Helper to parse the cache file with Nokogiri
  def self.doc
    File.open(CACHE_PATH) { |f| Nokogiri::XML(f) }
  end
end

