require 'exchange_rate'

class ExchangeController < ApplicationController
  def index
    valid_dates = ExchangeRate.dates
    # default Rails widget doesn't allow more fine-grained filtering
    # to include only days with data
    @min_date = valid_dates.last
    @max_date = valid_dates.first
    
    # persist inputs for next search
    @date = begin
      Date.parse(params[:date])
    rescue
      @max_date
    end
    
    @amount = params.key?(:amount) ? params[:amount] : "100"
    
    # default to first and second currencies
    @from_ccy = params.key?(:from_ccy) ? params[:from_ccy] : ExchangeRate::CURRENCIES.first 
    @to_ccy = params.key?(:to_ccy) ? params[:to_ccy] : ExchangeRate::CURRENCIES.second
  
    # build the list of currencies for the select boxes
    @currencies = ExchangeRate::CURRENCIES.map{|e| [e, e]}
      
    # output
    @result = begin
      return nil if @amount.blank?
      ExchangeRate.convert(@date, @amount, @from_ccy, @to_ccy)
    rescue => e
      # very crude error display
      e
    end
  end
end
